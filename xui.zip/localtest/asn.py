import requests
import re

def fetch_ip_prefixes(as_number):
    url = f"https://bgp.he.net/AS{as_number}#_prefixes"
    response = requests.get(url)

    if response.status_code == 200:
        ipcird_list = re.findall(r'\b\d+\.\d+\.\d+\.\d+/\d+\b', response.text)
        ipcird_list = list(set(ipcird_list))
        return ipcird_list
    else:
        print(f"Failed to fetch data for AS{as_number}")
        return []

def main():
    as_numbers = input("请输入AS号:").split(',')
    as_numbers = [asn.strip() for asn in as_numbers]

    all_ipcird_list = []

    for as_number in as_numbers:
        ipcird_list = fetch_ip_prefixes(as_number)
        all_ipcird_list.extend(ipcird_list)

    all_ipcird_list = list(set(all_ipcird_list))  # 去重

    with open("ipcird.txt", "w") as file:
        for ipcird in all_ipcird_list:
            file.write(ipcird + "\n")

    print("Data for all AS numbers saved to ipcird.txt")

if __name__ == "__main__":
    main()
